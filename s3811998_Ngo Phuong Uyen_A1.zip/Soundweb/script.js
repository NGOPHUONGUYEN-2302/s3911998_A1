// Setup synths
let synth = new Tone.Synth().toDestination();
Tone.Destination.volume.value = -12;
Tone.Transport.bpm.value = 120;

function getInstrument(name) {
    switch (name) {
        case "piano":
            return new Tone.Sampler({
                urls: { C4: "C4.mp3" },
                baseUrl: "https://tonejs.github.io/audio/salamander/",
            }).toDestination();
        case "guitar":
            return new Tone.MonoSynth().toDestination();
        case "flute":
            return new Tone.Synth({ oscillator: { type: "sine" } }).toDestination();
        case "drums":
            return new Tone.MembraneSynth().toDestination();
        case "violin":
            return new Tone.Synth({ oscillator: { type: "triangle" } }).toDestination();
        case "synth":
            return new Tone.FMSynth().toDestination();
        case "bass":
            return new Tone.MonoSynth({ oscillator: { type: "square" } }).toDestination();
        default:
            return new Tone.Synth().toDestination();
    }
}

// Event: Play
document.getElementById("playBtn").addEventListener("click", async () => {
    await Tone.start();

    
    const bpm = document.getElementById("bpm").value;
    const volume = document.getElementById("volume").value;
    const instrument = document.getElementById("instrument").value;

    Tone.Transport.bpm.value = parseInt(bpm);
    Tone.Destination.volume.value = parseFloat(volume);

    synth = getInstrument(instrument);

    const notes = ["C4", "E4", "G4", "B4"];
    let i = 0;
    Tone.Transport.scheduleRepeat(time => {
        synth.triggerAttackRelease(notes[i % notes.length], "8n", time);
        i++;
    }, "4n");

    Tone.Transport.start();
});

// Event: Stop
document.getElementById("stopBtn").addEventListener("click", () => {
    Tone.Transport.stop();
    Tone.Transport.cancel();
});

// Chatbox AI with Gemini API
const chatInput = document.getElementById("chat-input");
const chatLog = document.getElementById("chat-log");
const sendBtn = document.getElementById("send-btn");
const apiKey = "AIzaSyDNqo1YB--9cRnbnIhZdrpjtzExQow8940"; // Replace with your actual API key
const voice = document.getElementById("voice").value;
const playBtn = document.getElementById("play-btn");
const pauseBtn = document.getElementById("pause-btn");
const recordBtn = document.getElementById("record-btn");
const recordingStatus = document.getElementById("recording-status");

let speechUtterance = null; 
let isSpeaking = false;

// Speech Recognition API setup
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
let recognition = null;
if (SpeechRecognition) {
    recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.lang = 'en-US'; // Change to your desired language
    recognition.interimResults = false;
} else {
    console.warn("Speech Recognition API is not supported in this browser.");
    recordBtn.disabled = true;
    recordingStatus.textContent = "Speech Recognition not supported.";
}

// Function to handle sending messages
async function sendMessage() {
    const userMessage = chatInput.value.trim();
    if (userMessage !== "") {
        chatLog.innerHTML += `<div><strong>You:</strong> ${userMessage}</div>`;
        chatInput.value = "";

        try {
            const aiResponse = await getGeminiResponse(userMessage, apiKey);
            chatLog.innerHTML += `<div><strong>AI:</strong> ${aiResponse}</div>`;
            console.log("Calling speak() with:", aiResponse, voice); 
            speak(aiResponse, voice);
            enablePlayPauseButtons();
        } catch (error) {
            console.error("Error calling Gemini API:", error);
            chatLog.innerHTML += `<div><strong>AI:</strong> Sorry, I encountered an error. Please try again later.</div>`;
        }

        chatLog.scrollTop = chatLog.scrollHeight;
    }
}

// Event listener for send button
sendBtn.addEventListener("click", sendMessage);

// Event listeners for suggestion buttons
document.querySelectorAll('.suggestion-btn').forEach(button => {
    button.addEventListener('click', function() {
        chatInput.value = this.dataset.question;
    });
});

// Gemini API call function
async function getGeminiResponse(message, apiKey) {
    const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`,
        {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                contents: [{ parts: [{ text: message }] }],
            }),
        }
    );

    if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    return data.candidates[0].content.parts[0].text;
}

// Text-to-Speech function
function speak(text, voice) {
    console.log("speak() called with:", text, voice); 
    speechSynthesis.cancel(); 
    speechUtterance = new SpeechSynthesisUtterance(text); // Store utterance
    const synth = window.speechSynthesis;

    // Set voice based on selection
    let selectedVoice = null;
    if (voice === 'male') {
        selectedVoice = synth.getVoices().find(v => v.name.includes('Google US English')); // Adjust for male voice
    } else {
        selectedVoice = synth.getVoices().find(v => v.name.includes('Google US English Female')); // Adjust for female voice
    }

    if (selectedVoice) {
        speechUtterance.voice = selectedVoice;
        console.log("Selected voice:", selectedVoice.name); 
    } else {
        console.warn("No matching voice found for:", voice); 
    }

    speechUtterance.onstart = () => {
        isSpeaking = true;
        console.log("Speaking started"); 
    };
    speechUtterance.onend = () => {
        isSpeaking = false;
        disablePlayPauseButtons();
        console.log("Speaking ended"); 
    };
    speechUtterance.onpause = () => {
        isSpeaking = false;
        console.log("Speaking paused"); 
    };
    speechUtterance.onresume = () => {
        isSpeaking = true;
        console.log("Speaking resumed"); 
    };

    console.log("Calling speechSynthesis.speak()"); 
    synth.speak(speechUtterance);
}

// Play button functionality
playBtn.addEventListener('click', () => {
    if (speechSynthesis.paused) {
        speechSynthesis.resume();
        console.log("Resuming speech");
    }
});

// Pause button functionality
pauseBtn.addEventListener('click', () => {
    if (speechSynthesis.speaking) {
        speechSynthesis.pause();
        console.log("Pausing speech");
    }
});

// Enable/Disable play/pause buttons
function enablePlayPauseButtons() {
    playBtn.disabled = false;
    pauseBtn.disabled = false;
    console.log("Play/Pause buttons enabled");
}

function disablePlayPauseButtons() {
    playBtn.disabled = true;
    pauseBtn.disabled = true;
    console.log("Play/Pause buttons disabled");
}

// Speech Recognition functionality
if (recognition) {
    recordBtn.addEventListener('click', () => {
        if (recordBtn.textContent === 'Record') {
            startRecording();
        } else {
            stopRecording();
        }
    });

    function startRecording() {
        recognition.start();
        recordBtn.textContent = 'Stop';
        recordingStatus.textContent = 'Recording...';
        chatInput.disabled = true; // Disable text input during recording
    }

    function stopRecording() {
        recognition.stop();
        recordBtn.textContent = 'Record';
        recordingStatus.textContent = 'Processing...';
    }

    recognition.onstart = () => {
        console.log("Speech recognition service has started");
    };

    recognition.onresult = (event) => {
        const transcript = Array.from(event.results)
            .map(result => result[0])
            .map(result => result.transcript)
            .join('');

        chatInput.value = transcript;
        recordingStatus.textContent = 'Ready';
        chatInput.disabled = false; // Re-enable text input after recording
    };

    recognition.onend = () => {
        console.log("Speech recognition service disconnected");
        recordingStatus.textContent = 'Recording stopped';
        recordBtn.textContent = 'Record';

        // After recording is done, automatically send the message
        sendMessage();
    };

    recognition.onerror = (event) => {
        console.error("Speech recognition error:", event.error);
        recordingStatus.textContent = `Error: ${event.error}`;
        chatInput.disabled = false; // Re-enable text input in case of error
        recordBtn.textContent = 'Record';
    };
}